package com.example.socnet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
